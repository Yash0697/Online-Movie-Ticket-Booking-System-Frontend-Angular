import { FilterseatlistPipe } from './filterseatlist.pipe';

describe('FilterseatlistPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterseatlistPipe();
    expect(pipe).toBeTruthy();
  });
});
