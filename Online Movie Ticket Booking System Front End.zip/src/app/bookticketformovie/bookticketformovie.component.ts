import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookticketformovie',
  templateUrl: './bookticketformovie.component.html',
  styleUrls: ['./bookticketformovie.component.css']
})
export class BookticketformovieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
