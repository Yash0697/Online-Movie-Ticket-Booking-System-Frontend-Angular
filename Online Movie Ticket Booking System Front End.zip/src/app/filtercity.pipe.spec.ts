import { FiltercityPipe } from './filtercity.pipe';

describe('FiltercityPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltercityPipe();
    expect(pipe).toBeTruthy();
  });
});
