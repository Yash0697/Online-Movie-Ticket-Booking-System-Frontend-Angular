import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-by-movie-name',
  templateUrl: './search-by-movie-name.component.html',
  styleUrls: ['./search-by-movie-name.component.css',
              '../../css/bootstrap-grid.min.css',
              '../../css/bootstrap-reboot.min.css',
              '../../css/main.css']
})
export class SearchByMovieNameComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
